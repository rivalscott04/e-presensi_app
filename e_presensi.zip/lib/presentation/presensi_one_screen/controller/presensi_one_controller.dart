import '/core/app_export.dart';
import 'package:e_presensi/presentation/presensi_one_screen/models/presensi_one_model.dart';

class PresensiOneController extends GetxController {
  Rx<PresensiOneModel> presensiOneModelObj = PresensiOneModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
