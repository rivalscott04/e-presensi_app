import '/core/app_export.dart';
import 'package:e_presensi/presentation/presensi_two_dialog/models/presensi_two_model.dart';

class PresensiTwoController extends GetxController {
  Rx<PresensiTwoModel> presensiTwoModelObj = PresensiTwoModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
