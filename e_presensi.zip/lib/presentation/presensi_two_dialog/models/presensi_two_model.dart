class PresensiTwoModel {}
