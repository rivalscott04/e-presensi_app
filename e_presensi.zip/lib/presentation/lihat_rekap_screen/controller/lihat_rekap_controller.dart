import '/core/app_export.dart';
import 'package:e_presensi/presentation/lihat_rekap_screen/models/lihat_rekap_model.dart';

class LihatRekapController extends GetxController {
  Rx<LihatRekapModel> lihatRekapModelObj = LihatRekapModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
