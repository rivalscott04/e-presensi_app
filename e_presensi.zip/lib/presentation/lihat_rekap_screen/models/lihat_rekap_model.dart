import 'package:get/get.dart';
import 'lihat_rekap_item_model.dart';

class LihatRekapModel {
  RxList<LihatRekapItemModel> lihatRekapItemList =
      RxList.filled(7, LihatRekapItemModel());
}
