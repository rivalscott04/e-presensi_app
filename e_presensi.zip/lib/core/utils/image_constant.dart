class ImageConstant {
  static String imgArrowleft = 'assets/images/img_arrowleft.svg';

  static String imgImage2 = 'assets/images/img_image2.png';

  static String imgGroup6 = 'assets/images/img_group6.png';

  static String imgContrast = 'assets/images/img_contrast.svg';

  static String imgMenu = 'assets/images/img_menu.svg';

  static String imgClock = 'assets/images/img_clock.svg';

  static String imgVideocamera = 'assets/images/img_videocamera.svg';

  static String imgGroup20 = 'assets/images/img_group20.svg';

  static String imgArrowright = 'assets/images/img_arrowright.svg';

  static String imgMenu24X24 = 'assets/images/img_menu_24X24.svg';

  static String imgUser = 'assets/images/img_user.svg';

  static String imgVektor1 = 'assets/images/img_vektor1.png';

  static String imgVektor2 = 'assets/images/img_vektor2.png';

  static String imgUpload = 'assets/images/img_upload.svg';

  static String imgEllipse49 = 'assets/images/img_ellipse49.png';

  static String imgIllustration = 'assets/images/img_illustration.svg';

  static String imgImage1 = 'assets/images/img_image1.png';

  static String imgMenu26X26 = 'assets/images/img_menu_26X26.svg';

  static String imgUser24X24 = 'assets/images/img_user_24X24.svg';

  static String imgClock65X65 = 'assets/images/img_clock_65X65.svg';

  static String imgVector2 = 'assets/images/img_vector2.png';

  static String imgEye = 'assets/images/img_eye.svg';

  static String imgCalendar = 'assets/images/img_calendar.svg';

  static String imgVektor1296X375 = 'assets/images/img_vektor1_296X375.png';

  static String imgHome = 'assets/images/img_home.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
