import 'package:e_presensi/core/app_export.dart';

class ApiClient extends GetConnect {}
